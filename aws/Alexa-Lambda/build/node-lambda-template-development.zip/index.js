var Alexa = require('alexa-app');
var App = new Alexa.app('OfficeHUB');

App.intent('signOut', {
	slots: {},
	utterances: [
		'sign me out',
		'log me out',
		'log out',
		'sign out'
	]
}, function(request,response) {
//	var number = request.slot('number');
	response.say("You asked for this");
});

